<nav class="navbar navbar-expand-lg navbar-primary bg-light">
        <img src="resource/img/hi.png" class="logo" alt="logo">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav ml-auto">
            <a class="nav-link active" href="studentportal">Home <span class="sr-only">(current)</span></a>
            <a class="nav-link" href="updateprofile.php">Update Profile</a>
            <a class="nav-link" href="changepassword.php">Change Password </a>
            <a class="nav-link" href="logout.php">Logout</a>

    </div>
  </div>
</nav>
